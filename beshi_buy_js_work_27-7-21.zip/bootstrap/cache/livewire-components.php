<?php return array (
  'admin.front-layout.layout' => 'App\\Http\\Livewire\\Admin\\FrontLayout\\Layout',
);